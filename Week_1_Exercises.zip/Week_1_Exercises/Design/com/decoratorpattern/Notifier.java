package com.decoratorpattern;

public interface Notifier {
    void send(String message);
}
