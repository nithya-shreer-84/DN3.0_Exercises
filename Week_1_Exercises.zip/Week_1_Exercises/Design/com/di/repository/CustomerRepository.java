package com.di.repository;

public interface CustomerRepository {
    String findCustomerById(String customerId);
}
