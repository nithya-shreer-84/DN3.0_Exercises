package com.observerpattern;

public interface Observer {
    void update(double stockPrice);
}
